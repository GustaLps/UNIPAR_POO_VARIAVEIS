ATIVIDADE 1
    
class HelloWorld {
    public static void main(String[] args) {
        String nome;
        float valor = 1.2f;
        int idade = 10;
        Integer ano = 50;
        double peso = 80.5;
        boolean confirma = true;
        char sexo = 'M';
        long numG = 323432423434;
        byte numP = 2334
        short numC = 123
    }
}

ATIVIDADE 2

class AT2 {
    public static void main(String[] args) {
        String nomeProduto;
        double precoProduto; 
        String marcaDoProduto; 
        int quantidadeProduto; 
        String descricaoProduto; 
        String nomeDoProduto;
        int numeroProduto; 
        double precoDoProduto; 
        int estoqueDisponivel; 
        int totalDeProdutos;
    }
}

ATIVIDADE 3

String nomeDoAluno = "Gustavo"; 
  int idadeDoAluno = 19; 
  double notaDaProva1 = 8.5; 
  double notaDaProva2 = 5.0; 
  double mediaFinal = 6.75;

ATIVIDADE 4

public class ControleEstoque {
    public static void main(String[] args) {
        
        String nomeProduto;
        String categoriaProduto
        double precoUnitario;
        int qtdEmProduto

    }
}

ATIVIDADE 5

public class AT5 {
    public static void main(String[] args) {
        
        String nomeSmartphone = "Redmi note 8";
        String marcaSmartphone = "Xiaomi";
        double precoSmartphone = 1200.00;
        int qtdSmartphone = 50;
        
        System.out.println("Dados do Smartphone:");
        System.out.println("Nome: " + nomeSmartphone);
        System.out.println("Marca: " + marcaSmartphone);
        System.out.println("Preco: " + precoSmartphone);
        System.out.println("Estoque: " + qtdSmartphone);
       
       System.out.println(" ");
        
        String nomeLaptop = "G15";
        String marcaLaptop = "Dell";
        double precoLaptop = 5000.00;
        int qtdLaptop = 10;
        
        System.out.println("Dados do Laptop:");
        System.out.println("Nome: " + nomeLaptop);
        System.out.println("Marca: " + marcaLaptop);
        System.out.println("Preco: " + precoLaptop);
        System.out.println("Estoque: " + qtdLaptop);
        
        System.out.println(" ");
        
        String nomeFoneDeOuvido = "AirPods";
        String marcaFoneDeOuvido = "Apple";
        double precoFoneDeOuvido = 1100.00;
        int qtdFoneDeOuvido = 40;
        
        System.out.println("Dados do Fone De Ouvido:");
        System.out.println("Nome: " + nomeFoneDeOuvido);
        System.out.println("Marca: " + marcaFoneDeOuvido);
        System.out.println("Preco: " + precoFoneDeOuvido);
        System.out.println("Estoque: " + qtdFoneDeOuvido);
        
      
    }
}

ATIVIDADE 6

public class Main {
    public static void main(String[] args) {
       
        int numeroProduto = 123; 
        double precoProduto = 25; 
        
        String descricaoProduto;
        descricaoProduto = "Fone de ouvido Bluetooth";
        
        System.out.println("Descricao do Produto: " + descricaoProduto);
        
        
        System.out.println("Dados do Produto:");
        System.out.println("Nuumero: " + numeroProduto);
        System.out.println("Preco: $" + precoProduto);
        System.out.println("Descricao: " + descricaoProduto);
    }
}

ATIVIDADE 7

public class ControleEstoque {
    public static void main(String[] args) {
        
        String marcaProduto;
        String nomeProduto;
        double precoProduto;
        int quantidadeProduto;
        
        marcaProduto = "xaomi";
        nomeProduto = "fone de ouvido";
        precoProduto = 29.99;
        quantidadeProduto = 10;
       
        System.out.println("Dados do Produto: ");
        System.out.println("Nome: " + nomeProduto);
        System.out.println("Marca: " + marcaProduto);
        System.out.println("Preco: $" + precoProduto);
        System.out.println("Quantidade em estoque: " + quantidadeProduto);
    }
}

    
